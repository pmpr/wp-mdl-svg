<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b755e1b5b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG\Sanitizer; use enshrined\svgSanitize\data\AllowedAttributes; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; class Attribute extends AllowedAttributes { use HelperTrait; public static function getAttributes() { $siquossayskcwkea = parent::getAttributes(); return self::iwgqamekocwaigci()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\163\166\x67\137\x61\154\154\157\x77\x65\144\x5f\x61\164\164\x72\x69\x62\x75\164\145\x73", $siquossayskcwkea); } }
