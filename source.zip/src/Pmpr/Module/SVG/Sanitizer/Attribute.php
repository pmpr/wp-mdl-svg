<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bc9dd954             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG\Sanitizer; use enshrined\svgSanitize\data\AllowedAttributes; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; class Attribute extends AllowedAttributes { use HelperTrait; public static function getAttributes() { $siquossayskcwkea = parent::getAttributes(); return self::iwgqamekocwaigci()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\x73\166\147\137\x61\x6c\x6c\x6f\167\145\x64\x5f\141\x74\x74\162\x69\x62\165\164\x65\163", $siquossayskcwkea); } }
