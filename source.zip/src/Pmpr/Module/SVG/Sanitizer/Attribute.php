<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680d58fa7f960             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG\Sanitizer; use enshrined\svgSanitize\data\AllowedAttributes; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; class Attribute extends AllowedAttributes { use HelperTrait; public static function getAttributes() { $siquossayskcwkea = parent::getAttributes(); return self::iwgqamekocwaigci()->mmsykuomogaqoaye()->ocksiywmkyaqseou('svg_allowed_attributes', $siquossayskcwkea); } }
