<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069bb887d8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG\Sanitizer; use enshrined\svgSanitize\data\AllowedTags; use Pmpr\Common\Foundation\Helper\Traits\HelperTrait; class Tag extends AllowedTags { use HelperTrait; public static function getTags() { $kmmywmgcgwceeqii = parent::getTags(); return self::iwgqamekocwaigci()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\x73\166\x67\x5f\x61\x6c\154\x6f\167\x65\144\137\x74\x61\147\163", $kmmywmgcgwceeqii); } }
