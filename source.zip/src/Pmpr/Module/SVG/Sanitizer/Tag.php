<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b755e1b5b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG\Sanitizer; use enshrined\svgSanitize\data\AllowedTags; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; class Tag extends AllowedTags { use HelperTrait; public static function getTags() { $kmmywmgcgwceeqii = parent::getTags(); return self::iwgqamekocwaigci()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\x73\x76\147\137\x61\154\154\x6f\x77\145\144\x5f\164\x61\147\x73", $kmmywmgcgwceeqii); } }
