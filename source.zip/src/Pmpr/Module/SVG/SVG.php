<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc21bdb210             |
    |_______________________________________|
*/
 namespace Pmpr\Module\SVG; use Pmpr\Common\Foundation\Container\ComponentInitiator; class SVG extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x53\x56\107", PR__MDL__SVG); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
